
def hello(event, context):
    print("Farts !")
    return "Hello World"

